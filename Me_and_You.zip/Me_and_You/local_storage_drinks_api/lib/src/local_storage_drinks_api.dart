import 'dart:convert';
import 'package:drinks_api/drinks_api.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

const _delay = Duration(milliseconds: 800);

class LocalStorageDrinksApi implements DrinksApi {
  @override
  Future<List<Categories>> fetchdrinks([int startIndex = 0]) async {
    final response = await http.get(Uri.parse(
        'https://raw.githubusercontent.com/madhusona/me/main/db.json'));

    if (response.statusCode == 200) {
      Map<String, dynamic> a = json.decode(response.body);

      List<dynamic> cat = a["services"][0]["categories"];

      // ignore: non_constant_identifier_names
      List<Categories> Lcategories = [];

      for (var i = 0; i < cat.length; i++) {
        Map<String, dynamic> b = a["categories"][cat[i]];
        // ignore: non_constant_identifier_names
        List<Items> Litems = [];
        Lcategories.insert(i, Categories.fromJson(b, Litems));

        for (var j = 0; j < Lcategories[i].menuItems.length; j++) {
          Map<String, dynamic> menu = a["items"][Lcategories[i].menuItems[j]];
          // ignore: non_constant_identifier_names
          List<Variants> Lvariants = [];
          // ignore: non_constant_identifier_names
          List<Modifiers> Lmodifiers = [];

          if (menu.containsKey("variants")) {
            for (var k = 0; k < menu["variants"].length; k++) {
              Map<String, dynamic> vari = menu["variants"][k] ?? "empty";

              Variants a = Variants.fromJson1(vari);
              // print(a.displayName);
              Lvariants.insert(k, Variants.fromJson1(vari));
              //   print(Lvariants);
            }
          } else {
            if (kDebugMode) {
              print("empty");
            }
          }

          if (menu.containsKey("modifiers")) {
            for (var m = 0; m < menu["modifiers"].length; m++) {
              Map<String, dynamic> modif = menu["modifiers"][m] ?? "empty";
              // ignore: non_constant_identifier_names
              List<Options> Loptions = [];

              Modifiers a = Modifiers.fromJson2(modif, Loptions);
              if (modif.containsKey("options")) {
                for (var d = 0; d < modif["options"].length; d++) {
                  Map<String, dynamic> option = modif["options"][d] ?? "empty";
                  Options a = Options.fromJson2(option);
                  Loptions.insert(d, Options.fromJson2(option));
                }

                Lmodifiers.insert(m, Modifiers.fromJson2(modif, Loptions));
              }
            }
          } else {
            if (kDebugMode) {
              print("empty");
            }
          }
          // print(Lmodifiers);

          Litems.insert(j, Items.fromJson(menu, Lvariants, Lmodifiers));
        }

        //  print(Lcategories);
      }
      // print(Lcategories);
      return Lcategories;
    } else {
      throw Exception('Failed to load album');
    }
  }

  @override
  Future<List<Items>> LoadCartItems(Items item, String variant) {
    final I = LoadCartItems(item, variant);
    return I;
  }
}
