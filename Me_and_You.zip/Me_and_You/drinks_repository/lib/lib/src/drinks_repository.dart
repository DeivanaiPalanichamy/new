import 'package:drinks_api/drinks_api.dart';

class DrinksRepository {
  const DrinksRepository({
    required DrinksApi drinksApi,
  }) : _drinksApi = drinksApi;
  final DrinksApi _drinksApi;
  Future<List<Categories>> fetchdrinks() => _drinksApi.fetchdrinks();
  Future<List<Items>> LoadCartItems(Items item,String variant) => _drinksApi.LoadCartItems(item,variant);
}
