import 'models/model/Categoriesmodel/categories.dart';
import 'package:drinks_api/drinks_api.dart';

/// {@template todos_api}
/// The interface for an API that provides access to a list of todos.
/// {@endtemplate}

 abstract class DrinksApi {
  /// {@macro todos_api}
  const DrinksApi();

  
  Future<List<Categories>> fetchdrinks();
  Future<List<Items>> LoadCartItems(Items item,String variant);
}
