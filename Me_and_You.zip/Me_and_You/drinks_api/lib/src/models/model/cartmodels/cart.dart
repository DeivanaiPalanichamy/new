import 'package:equatable/equatable.dart';

import '../Categoriesmodel/items.dart';

class Cart extends Equatable {
  const Cart({
    this.items = const <Items>[],
    this.variant = const<String>[],
  });

  final List<Items> items;
  final List<String> variant;

  @override
  List<Object> get props => [items,variant];
}
