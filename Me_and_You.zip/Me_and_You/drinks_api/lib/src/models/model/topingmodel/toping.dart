import 'package:equatable/equatable.dart';
//import 'package:httpreq/model/Categoriesmodel/variantsmodel.dart';

class Toping extends Equatable {
  const Toping({
   // this.variants = const <Variants>[],
    this.variant= const <double>[],
  });

 // final List<Variants> variants;
  final List<double> variant;

  @override
  List<Object> get props => [variant];
}
