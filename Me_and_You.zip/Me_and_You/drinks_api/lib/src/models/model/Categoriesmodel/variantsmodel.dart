import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';


@immutable
class Variants extends Equatable {
  const Variants({
    required this.displayName,
    required this.price,
  });
  const Variants.empty()
      : this(
          displayName: null,
          price: null,
        );

  final String? displayName;
  final String? price;

  factory Variants.fromJson1(Map<String, dynamic> json) {
    return Variants(
      displayName: json['displayName'],
      price: json['price'],
    );
  }

  @override
  List<Object?> get props => [
        displayName,
        price,
      ];

  static delayed(Duration delay, List<Variants> Function() param1) {}
}
