import 'package:equatable/equatable.dart';

import 'items.dart';

// ignore: must_be_immutable
class Categories extends Equatable {
  String? course;
  String? displayName;
  String? images;
  List menuItems;
  bool? showFromPrice;
  String? type;
  List<Items> items;


  Categories(
      {this.course,
      this.displayName,
      required this.menuItems,
      this.images,
      this.showFromPrice,
      required this.items,
      this.type});
  Categories.empty()
      : this(
          course: null,
          displayName: null,
          menuItems: List.empty(),
          images: null,
          showFromPrice: false,
          items: List.empty(),
          type: null,
        
        );

  factory Categories.fromJson(Map<String, dynamic> json, List<Items> litems) {
    return Categories(
      course: json['course'],
      images: json['images']['thumb'],
      displayName: json['displayName'],
      menuItems: json["menuItems"],
      showFromPrice: json['showFromPrice'],
      type: json['type'],
      items: litems,
      
    );
  }
 

  @override
  List<Object?> get props =>
      [course, displayName, showFromPrice, menuItems, images, items, type];
}
