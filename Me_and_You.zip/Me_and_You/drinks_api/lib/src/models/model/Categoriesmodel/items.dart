// ignore_for_file: non_constant_identifier_names

import 'package:equatable/equatable.dart';

import '../../../../drinks_api.dart';

// ignore: must_be_immutable
class Items extends Equatable {
  String? description;
  String? displayName;
  String? images;
  String? price;
  String? type;
  List<Variants> variants;
  List<Modifiers> modifiers;

  Items(
      {this.description,
      this.displayName,
      this.images,
      this.price,
      this.type,
      required this.variants,
      required this.modifiers});

  Items.empty()
      : this(
          description: null,
          displayName: null,
          images: null,
          price: null,
          type: null,
          variants: List.empty(),
          modifiers: List.empty(),
        );

  factory Items.fromJson(
    Map<String, dynamic> json,
    List<Variants> Lvariants,
    List<Modifiers> Lmodifiers,
  ) {
    return Items(
      description: json['description'],
      images: json['images']['thumb'],
      displayName: json['displayName'],
      price: json['price'],
      type: json['type'],
      variants: Lvariants,
      modifiers: Lmodifiers,
    );
  }

  @override
  List<Object?> get props =>
      [description, displayName, price, images, type, variants, modifiers];
}
