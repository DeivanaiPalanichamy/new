import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';


@immutable
// ignore: must_be_immutable
class Modifiers extends Equatable {
   Modifiers({
 this.displayName,
   required this.options,
  });
  Modifiers.empty()
      : this(
          displayName: null,
          options: List<Options>.empty(),
        );

  final String? displayName;
 List<Options> options;

  
  // ignore: non_constant_identifier_names
  factory Modifiers.fromJson2(Map<String, dynamic> json, List<Options> Loptions) {
    return Modifiers(
      displayName: json['displayName'],
       options: Loptions,
    );
  }

  @override
  List<Object?> get props => [
        displayName,
       options,
      ];
}
class Options extends Equatable {
   const Options({
  this.displayName,
    
  });
   const Options.empty()
      : this(
          displayName: null,
         
        );

  final String? displayName;
 

  
  factory Options.fromJson2(Map<String, dynamic> json) {
    return Options(
      displayName: json['displayName'],
     
    );
  }

  @override
  List<Object?> get props => [
        displayName,
      ];
}
