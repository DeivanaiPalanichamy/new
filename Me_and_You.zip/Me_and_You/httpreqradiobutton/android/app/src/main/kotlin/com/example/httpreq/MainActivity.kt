package com.example.httpreq

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
