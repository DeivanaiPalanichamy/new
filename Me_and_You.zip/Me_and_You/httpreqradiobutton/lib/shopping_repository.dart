import 'dart:async';

import 'package:drinks_api/drinks_api.dart';

const _delay = Duration(milliseconds: 800);

class ShoppingRepository {
  
    final List<Items> _items = [];
    final List<double> _variants = [];

    Future<List<Items>> loadCartItems() => Future.delayed(_delay, () => _items);
    Future<List<dynamic>> loadCartToping() =>
        Future.delayed(_delay, () => _variants);

    void addItemToCart(Items item, String variant) => _items.add(item);
    void addItemToToping(double variant) => _variants.add(variant);

    void removeItemFromCart(Items item, String variant) => _items.remove(item);
    void removeItemFromToping(Variants variant) => _items.remove(variant);
  
}
