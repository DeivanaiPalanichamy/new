import 'package:drinks_api/drinks_api.dart';
import 'package:drinks_repository/lib/drinks_repository.dart';
import 'package:get_it/get_it.dart';
import 'package:local_storage_drinks_api/local_storage_drinks_api.dart';
import 'package:injectable/injectable.dart';


GetIt locator = GetIt.instance;


Future<void> init()  async{
 // GetIt.instance.registerSingleton<DrinksRepository>(LocalStorageDrinksApi() as DrinksRepository);
  locator.registerLazySingleton<DrinksRepository>(
      () => DrinksRepository(drinksApi: locator()));

  locator.registerLazySingleton<DrinksApi>(
      () => LocalStorageDrinksApi());
  

 
}
