part of 'post_bloc.dart';


enum PostStatus { initial, success, failure }

class PostState extends Equatable {
  const PostState({
    this.status = PostStatus.initial,
    this.categories = const <Categories>[],
    this.hasReachedMax = false,
  });

  final PostStatus status;
  final List<Categories> categories;
  final bool hasReachedMax;

  PostState copyWith({
    PostStatus? status,
    List<Categories>? categories,
    bool? hasReachedMax,
  }) {
    return PostState(
      status: status ?? this.status,
      categories: categories ?? this.categories,
      hasReachedMax: hasReachedMax ?? this.hasReachedMax,
    );
  }

  @override
  String toString() {
    return '''PostState { status: $status, hasReachedMax: $hasReachedMax, posts: ${categories.length} }''';
  }

  @override
  List<Object> get props => [status, categories, hasReachedMax];
}
