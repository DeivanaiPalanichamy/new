import 'package:bloc/bloc.dart';
import 'package:bloc_concurrency/bloc_concurrency.dart';
import 'package:drinks_repository/lib/drinks_repository.dart';
import 'package:httpreq/bloc/cart/cart_bloc.dart';
import 'package:local_storage_drinks_api/local_storage_drinks_api.dart';
import 'package:stream_transform/stream_transform.dart';

import 'package:equatable/equatable.dart';
import 'package:drinks_api/drinks_api.dart';

part 'post_event.dart';
part 'post_state.dart';

const _postLimit = 20;
const throttleDuration = Duration(milliseconds: 100);

EventTransformer<E> throttleDroppable<E>(Duration duration) {
  return (events, mapper) {
    return droppable<E>().call(events.throttle(duration), mapper);
  };
}

class PostBloc extends Bloc<PostEvent, PostState>
    implements LocalStorageDrinksApi {
  PostBloc({
    required DrinksRepository drinksRepository,
  })  : _drinksRepository = drinksRepository,
        super(const PostState()) {
    on<PostFetched>(
      _onPostFetched,
      transformer: throttleDroppable(throttleDuration),
    );
  }
  final DrinksRepository _drinksRepository;

  Future<void> _onPostFetched(
    PostFetched event,
    Emitter<PostState> emit,
  ) async {
    if (state.hasReachedMax) return;
    try {
      if (state.status == PostStatus.initial) {
        final categories = await _drinksRepository.fetchdrinks();
       
        return emit(
          state.copyWith(
            status: PostStatus.success,
            categories: categories,
            hasReachedMax: false,
          ),
        );
      }
    } catch (_) {
      emit(state.copyWith(status: PostStatus.failure));
    }
  }
  
  @override
  Future<List<Items>> LoadCartItems(Items item, String variant) {
    // TODO: implement LoadCartItems
    throw UnimplementedError();
  }
  
  @override
  Future<List<Categories>> fetchdrinks([int startIndex = 0]) {
    // TODO: implement fetchdrinks
    throw UnimplementedError();
  }

  
  
 

 

  
}
