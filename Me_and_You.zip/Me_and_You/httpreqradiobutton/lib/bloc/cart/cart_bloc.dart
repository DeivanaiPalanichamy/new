import 'package:bloc/bloc.dart';
import 'package:drinks_api/drinks_api.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:local_storage_drinks_api/local_storage_drinks_api.dart';

import '../../shopping_repository.dart';

part 'cart_event.dart';
part 'cart_state.dart';

class CartBloc extends Bloc<CartEvent, CartState>
    implements LocalStorageDrinksApi {
  CartBloc({required this.shoppingRepository}) : super(CartLoading()) {
    on<CartStarted>(_onStarted);
    on<CartItemAdded>(_onItemAdded);
    on<CartItemRemoved>(_onItemRemoved);
  }

  final ShoppingRepository shoppingRepository;

  Future<void> _onStarted(CartStarted event, Emitter<CartState> emit) async {
    emit(CartLoading());

    try {
      List<Items> items = await shoppingRepository.loadCartItems();

      emit(CartLoaded(
          cart: Cart(
        items: [...items],
      )));
  
    } catch (_) {
      emit(CartError());
    }
  }

  Future<void> _onItemAdded(
    CartItemAdded event,
    Emitter<CartState> emit,
  ) async {
    final state = this.state;

    print("hello");
    if (state is CartLoaded) {
      try {
        shoppingRepository.addItemToCart(event.item, event.variant);
        emit(CartLoaded(
            cart: Cart(
          items: [...state.cart.items, event.item],
          variant: [...state.cart.variant, event.variant],
        )));
      } catch (_) {
        emit(CartError());
      }
    }
  }

  Future<void> _onItemRemoved(
      CartItemRemoved event, Emitter<CartState> emit) async {
    final state = this.state;
    if (state is CartLoaded) {
      try {
        shoppingRepository.removeItemFromCart(event.item, event.variant);
        emit(
          CartLoaded(
            cart: Cart(
              items: [...state.cart.items]..remove(event.item),
              variant: [...state.cart.variant]..remove(event.variant),
            ),
          ),
        );
      } catch (_) {
        emit(CartError());
      }
    }
  }

  @override
  Future<List<Items>> loadCartItems(Items item, String variant) {
    final a = shoppingRepository.loadCartItems();
    print(a);
    return a;
  }

  @override
  Future<List<Items>> LoadCartItems(Items item, String variant) {
    // TODO: implement LoadCartItems
    throw UnimplementedError();
  }

  @override
  Future<List<Categories>> fetchdrinks([int startIndex = 0]) {
    // TODO: implement fetchdrinks
    throw UnimplementedError();
  }
}
