part of 'toping_bloc.dart';

@immutable
abstract class TopingEvent extends Equatable {
  const TopingEvent();
}

class TopingStarted extends TopingEvent {
  @override
  List<Object> get props => [];
}

class TopingItemAdded extends TopingEvent {
  const TopingItemAdded(/*this.varian,*/this.variant);

  //final List<Variants> varian;
  final double variant;

  @override
  List<Object> get props => [variant];
}


class TopingItemRemoved extends TopingEvent {
  const TopingItemRemoved(this.varian);

   final List<Variants> varian;

  @override
  List<Object> get props => [varian];
}
