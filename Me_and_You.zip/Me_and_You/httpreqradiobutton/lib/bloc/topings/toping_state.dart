part of 'toping_bloc.dart';
@immutable
abstract class TopingState extends Equatable {
  const TopingState();

}

class TopingLoading extends TopingState {
  

  @override
  List<Object> get props => [];
}


class TopingLoaded extends TopingState {
  const TopingLoaded({this.toping =  const Toping()}) ;

  final Toping toping;

  @override
  List<Object> get props => [toping];
}


class TopingError extends TopingState {
  

  @override
  List<Object> get props => [];
}
