import 'package:bloc/bloc.dart';
import 'package:drinks_api/drinks_api.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

import '../../shopping_repository.dart';


part 'toping_event.dart';
part 'toping_state.dart';

class TopingBloc extends Bloc<TopingEvent, TopingState> {
  TopingBloc({required this.shoppingRepository}) : super(TopingLoaded()) {
    on<TopingStarted>(_onTopStarted);
    on<TopingItemAdded>(_onTopItemAdded);

    on<TopingItemRemoved>(_onTopItemRemoved);
  }

  final ShoppingRepository shoppingRepository;

  Future<void> _onTopStarted(
      TopingStarted event, Emitter<TopingState> emit) async {
    emit(TopingLoaded());

    try {
      List<dynamic> variants = await shoppingRepository.loadCartToping();
      
     
      emit(TopingLoaded(
          toping: Toping(
        variant: [...variants],
      
      )
      )
      );
       
    } catch (_) {
      emit(TopingError());
    }
  }

  Future<void> _onTopItemAdded(
    TopingItemAdded event,
    Emitter<TopingState> emit,
  ) async {
    final state = this.state;

   
    if (state is TopingLoaded) {
      try {
        shoppingRepository.addItemToToping(
             event.variant);
     
       
       emit(TopingLoaded(
            toping: Toping(
         // variants: [...state.toping.variants, event.varian as Variants ],
          variant: [...state.toping.variant, event.variant],
          
        )
        )
        );
         
      } 
      catch (_) {
        emit(TopingError());
      }
    }
  }

  void _onTopItemRemoved(TopingItemRemoved event, Emitter<TopingState> emit) {
    final state = this.state;
    if (state is TopingLoaded) {
      try {
        shoppingRepository.removeItemFromToping(event.varian as Variants);
        emit(
          TopingLoaded(
            toping: Toping(
              variant: [...state.toping.variant]
                ..remove(event.varian as Variants),
            ),
          ),
        );
      } catch (_) {
        emit(TopingError());
      }
    }
  }
}
