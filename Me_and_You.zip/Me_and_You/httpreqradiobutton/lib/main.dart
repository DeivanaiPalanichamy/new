/*Version # : 1
Modified Date & By :  -13/12/2022- & -Deivanai-
Changes Summary:  removal of cart items.

*/ /*Version # : 1
Modified Date & By :  -12/12/2022- & -Deivanai-
Changes Summary: I had used Toping bloc for adding the radio button value. and given the value of variant in cart by processing toping bloc by increamenting and decreamenting the items of variants price.
Cart page is modified with total calculation. 

*/ /*Version # : 1
Modified Date & By :  -06/12/2022- & -Deivanai-
Changes Summary: i had used get_it package to reuse service as a servie locator by registering the object for reuse from any part of the project.
It consist of three like drinks api(abstract class of implementation in localstoragedrinksApi), drink repository(repository created for drinksApi fetch drinkfunction) and local storagedrinksapi(implementation of fetch drink function.
By using getit injector i used this three in injection.dart and given to post bloc).

*/
/*Version # : 1
Modified Date & By :  -05/12/2022- & -Deivanai-
Changes Summary: I had used 3 layers API , repository and localStoragedrinksapi. where i had seperated models and fetchdrink from post bloc.

*/

/*
 Version # : 
Modified Date & By :  -4/10/2022- & -Deivanai-
Changes Summary: I had given the value:[service][0][categories] to secondRoute dart page for nextsceen to access first screen value.

*/ /*Version # : 1
Modified Date & By :  -29/09/2022- & -Deivanai-
Changes Summary: I had loaded simple [service][0][categories] items from network json file,
and parsing the value of index of  [service][0][categories] to categories to display their specific item using list view builder
and grid view builder.

*/
import 'package:drinks_api/drinks_api.dart';
import 'package:drinks_repository/lib/drinks_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:httpreq/injection.dart';
import 'package:httpreq/shopping_repository.dart';
import 'package:flutter_driver/driver_extension.dart';
import 'package:httpreq/simple_bloc_observer.dart';

import 'bloc/cart/cart_bloc.dart';
import 'bloc/posts/post_bloc.dart';

import 'bloc/topings/toping_bloc.dart';
import 'screen/Home.dart';

void main() {
  enableFlutterDriverExtension();
  Bloc.observer = SimpleBlocObserver();

  init();
  runApp(const App());
}

class App extends MaterialApp {
  const App({
    super.key,
  }) : super(home: const PostsPage());
}

class PostsPage extends StatelessWidget {
  const PostsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return RepositoryProvider(
      create: (context) => ShoppingRepository(),
      child: MultiBlocProvider(
        providers: [
          BlocProvider(
            create: (_) => PostBloc(
                drinksRepository:
                    DrinksRepository(drinksApi: locator<DrinksApi>()))
              ..add(PostFetched()),
          ),
          BlocProvider(
            create: (_) => CartBloc(shoppingRepository: ShoppingRepository())
              ..add(CartStarted()),
          ),
          BlocProvider(
            create: (_) => TopingBloc(shoppingRepository: ShoppingRepository())
              ..add(TopingStarted()),
          ),
        ],
        child: const MyApp(),
      ),
    );
  }
}
