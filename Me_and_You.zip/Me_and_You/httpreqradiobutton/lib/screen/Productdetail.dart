/*Version # : 4
Modified Date & By :  -12/10/2022- & -Deivanai-
Changes Summary: I had loaded  items  for cart page from value parshed from second Route page,
And i had used draggablescrollable sheet for diplaying vrious sub items options and designed the layout of cart page.

*/

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:httpreq/bloc/topings/toping_bloc.dart';

import 'package:httpreq/shopping_repository.dart';
import '../bloc/cart/cart_bloc.dart';

class Productdetail extends StatefulWidget {
  final value;
  
  const Productdetail({super.key, @required this.value});

  @override
  State<Productdetail> createState() => _ProductdetailState();
}

class _ProductdetailState extends State<Productdetail> {
  @override
  Widget build(BuildContext context) {
   
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      body: SizedBox(
        height: size.height,
        width: size.height,
        child: SafeArea(
          child: Stack(
            children: [
              Image.network(
                "https://mnumenuprddataae.azureedge.net/" + widget.value.images,
                fit: BoxFit.cover,
                width: double.infinity,
              ),
                InkWell(
              onTap: () {
                Navigator.of(context).pop();
              },
              child: const SizedBox(
                width: 35,
                height: 35,
                child: Icon(Icons.close),
              ),
            ),

              DraggableScrollableSheet(
                ///To drag the page with display of items modifiers and variants is listed.
                initialChildSize: 0.5,
                minChildSize: 0.13,
                maxChildSize: 0.9,
                builder:
                    (BuildContext context, ScrollController scrollController) {
                  return Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: ListView(
                      ///listview for whole set of modifiers and variants.
                      controller: scrollController,
                      children: <Widget>[
                        const Padding(
                          padding: EdgeInsets.all(5),
                        ),

                        header(value: widget.value),
                        description(value: widget.value),
                        variants(
                          value: widget.value,
                          shoppingRepository: ShoppingRepository(),
                        ),
                      ],
                    ),
                  );
                  // ignore: dead_code
                },
              ),

              // AddButton(),

              bottomCart(
                value: widget.value,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class header extends StatefulWidget {
  // ignore: prefer_typing_uninitialized_variables
  var value;
  header({Key? key, @required this.value}) : super(key: key);

  @override
  State<header> createState() => _headerState();
}

// ignore: camel_case_types
class _headerState extends State<header> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Text(
        widget.value.displayName ?? "empty",
         key: Key(widget.value.displayName ),
        textAlign: TextAlign.start,
        style: GoogleFonts.getFont(
          'Rubik',
          fontSize: 28,
          fontWeight: FontWeight.bold,
          decoration: TextDecoration.none,
          color: Colors.black,
        ),
      ),
    );
  }
}

class variants extends StatefulWidget {
  var value;
  var shoppingRepository;

  variants({
    Key? key,
    @required this.value,
    required this.shoppingRepository,
  }) : super(key: key);

  @override
  State<variants> createState() => _variantsState();
}

class _variantsState extends State<variants> {
  String modifier = '';
  String option = '';
  String variant = '';
  String subtitle = '';
  String v = '';
  int _itemCount = 0;
  double? long2;

  String s = '';

  void checkRadio(dynamic variant, double long2) async {
    setState(() {
      this.variant = variant;
      this.long2 = long2;
      _itemCount++;

     

      context.read<TopingBloc>().add(TopingItemAdded(long2));
    });
  }

  void checkRadio1(String value) {
    setState(() {
      this.modifier = value;

      _itemCount++;
    });
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    var item = widget.value;
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const variantsheader(),
        const SizedBox(height: 10),
        ListView.builder(
            controller: ScrollController(),
            shrinkWrap: true,
            scrollDirection: Axis.vertical,
            itemCount: widget.value.variants.length ?? "empty",
            // separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (BuildContext context, int index) {
              var selectedValue = '';
              return Container(
                height: 60,
                color: Colors.white,
                child: RadioListTile(
                    title: Text(
                      ///variants displayName is displayed.
                      widget.value.variants[index].displayName,
                       key: Key(widget.value.variants[index].displayName),

                      style: GoogleFonts.getFont(
                        'Rubik',
                        fontSize: 15,
                        color: Colors.black,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    subtitle: Text(widget.value.variants[index].price),
                    value: widget.value.variants[index].toString(),
                    groupValue: v,
                    onChanged: (value) {
                      s = widget.value.variants[index].price;
                      final splitted = s.split('\$');
                     
                      var b = (splitted.length) - 1;
                      var spli = splitted[b];

                      var long2 = double.parse('$spli');

                      checkRadio(value!, long2);
                      setState(
                        () {
                          v = value;

                          long2 = long2;
                        },
                      );

                      selected:
                      false;
                      activeColor:
                      Colors.green;
                    }),
              );
            }),
        ListView.builder(
            controller: ScrollController(),
            shrinkWrap: true,
            scrollDirection: Axis.vertical,
            itemCount: widget.value.modifiers.length ?? "empty",
            itemBuilder: (BuildContext context, int i) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const Padding(padding: EdgeInsets.all(10)),
                  Container(
                    padding: EdgeInsets.all(10),
                    child: Text(
                      widget.value.modifiers[i].displayName,
                       key: Key(widget.value.modifiers[i].displayName),
                      style: GoogleFonts.getFont(
                        'Rubik',
                        fontSize: 18,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  ListView.builder(
                      controller: ScrollController(),
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      itemCount:
                          widget.value.modifiers[i].options.length ?? "empty",
                     
                      itemBuilder: (BuildContext context, int inde) {
                        var selectedValue = '';
                        return Container(
                          height: 60,
                          color: Colors.white,
                          child: RadioListTile(
                            title: Text(
                             
                              widget
                                  .value.modifiers[i].options[inde].displayName,

                              style: GoogleFonts.getFont(
                                'Rubik',
                                fontSize: 15,
                                color: Colors.black,
                                decoration: TextDecoration.none,
                              ),
                            ),
                            value: widget
                                .value.modifiers[i].options[inde].displayName,
                            groupValue: option,
                            onChanged: (value) {
                              checkRadio1(value as String);
                              setState(() {
                                option = value.toString();
                          
                              });
                            },
                            selected: false,
                            activeColor: Colors.green,
                          ),
                        );
                      }),
                ],
              );
            }),
      ],
    );
  }
}

class variantsheader extends StatefulWidget {
  const variantsheader({Key? key}) : super(key: key);

  @override
  State<variantsheader> createState() => _variantsheaderState();
}

class _variantsheaderState extends State<variantsheader> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Required",
            textAlign: TextAlign.left,
            style: GoogleFonts.getFont(
              'Rubik',
              fontSize: 14,
              color: Colors.grey,
              decoration: TextDecoration.none,
            ),
          ),
          Text(
            "Type",
            style: GoogleFonts.getFont(
              'Rubik',
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black,
              decoration: TextDecoration.none,
            ),
          ),
        ],
      ),
    );
  }
}

class description extends StatefulWidget {
  // ignore: prefer_typing_uninitialized_variables
  var value;
  description({Key? key, @required this.value}) : super(key: key);

  @override
  State<description> createState() => _descriptionState();
}

// ignore: camel_case_types
class _descriptionState extends State<description> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),

      ///To display description of items.
      child: Text(
        widget.value.description ?? "",
        textAlign: TextAlign.left,
        style: GoogleFonts.getFont(
          'Rubik',
          fontSize: 14,
          color: Colors.grey,
          decoration: TextDecoration.none,
        ),
      ),
    );
  }
}

class bottomCart extends StatefulWidget {
  var value;

  bottomCart({
    Key? key,
    @required this.value,
  }) : super(key: key);

  @override
  State<bottomCart> createState() => _bottomCartState();
}

class _bottomCartState extends State<bottomCart> {
  String option = '';
  String v = '';
  int _itemCount = 1;

  //context.read<TopingBloc>().add(TopingItemAdded(long2));

  @override
  Widget build(BuildContext context) {
    var item = widget.value;

    

    final theme = Theme.of(context);
    return Align(
      alignment: Alignment.bottomCenter,
      child: Card(
          child: Row(
        children: [
      
          Row(
            children: <Widget>[
              IconButton(
                icon: Icon(Icons.remove),
                onPressed: () => setState(() => _itemCount--),
              ),
              Text(_itemCount.toString()),
              IconButton(
                  icon: Icon(Icons.add),
                  onPressed: () => setState(() {
                        _itemCount++;
                      }))
            ],
          ),

          const SizedBox(
            width: 30,
          ),

          Container(
            height: 35.0,
            width: 210,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black,
                  offset: Offset(0, 0),
                ),
              ],
            ),
            child: BlocBuilder<CartBloc, CartState>(builder: (context, state) {
              if (state is CartLoaded) {
                if (widget.value.price != null) {
                  var p = widget.value.price == null ? "" : widget.value.price;
                  final splitted = p.split('\$');
                 
                  var c = splitted.length - 1;
                  var spli = splitted[c];

                  var pricei = double.parse(spli);
              
                  var price = pricei * _itemCount;
            
                  v = price.toString();
                  return TextButton(
                    style: TextButton.styleFrom(
                      disabledForegroundColor: theme.primaryColor,
                    ),
                    onPressed: () {
                      Navigator.of(context).pop();

                      context.read<CartBloc>().add(CartItemAdded(item, v));
                    },
                    child: Text(
                      "Add for \$  $price",
                      textAlign: TextAlign.center,
                      style: GoogleFonts.getFont(
                        'Rubik',
                        fontSize: 14,
                        color: Colors.white,
                        decoration: TextDecoration.none,
                      ),
                    ),
                  );
                } else {
                  return TextButton(
                    style: TextButton.styleFrom(
                      disabledForegroundColor: theme.primaryColor,
                    ),
                    onPressed: () {
                      Navigator.of(context).pop();

                      context.read<CartBloc>().add(CartItemAdded(item, v));
                    },
                    child: Row(
                      children: [
                        Text(
                          "Add for \$",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.getFont(
                            'Rubik',
                            fontSize: 14,
                            color: Colors.white,
                            decoration: TextDecoration.none,
                          ),
                        ),
                      
                        BlocBuilder<TopingBloc, TopingState>(
                            builder: (context, state) {
                          if (state is TopingLoaded) {
                            if (state.toping.variant.length > 0) {
                              var a = (state.toping.variant.length) - 1;

                              double b = state.toping.variant[a] * _itemCount;
                              v = b.toString() == '' ? "" : b.toString();
                       
                              return Text(
                                b.toString(),
                                textAlign: TextAlign.center,
                                style: GoogleFonts.getFont(
                                  'Rubik',
                                  fontSize: 14,
                                  color: Colors.white,
                                  decoration: TextDecoration.none,
                                ),
                              );
                            } else {
                              Text("");
                            }
                          }
                          return Text("");
                        }),
                      ],
                    ),
                  );
                }
                return const Text('Something went wrong!');
              }
              return const Text('Something went wrong!');
            }),
          ),
        ],
      )),
    );
  }
}
