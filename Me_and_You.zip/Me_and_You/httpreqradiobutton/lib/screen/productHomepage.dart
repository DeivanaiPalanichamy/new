/*
Version # : 3
Modified Date & By :  -10/10/2022- & -Deivanai-
Changes Summary: In a listed categories of items  on tapped scrolled  to specific items type by using ScrollablePositionedlistview builder.
text overflowed in a card is corrected by using SizedBox(width: 260).  maxLines: 2, overflow: TextOverflow .ellipsis,
                                                        
*/ /*
 Version # : 3
Modified Date & By :  -5/10/2022- & -Deivanai-
Changes Summary: I had fetched the value:[service][0][categories] from  main dart page for nextsceen to access  value.
And i had listed the categories of items displayed in the screen.
*/

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:httpreq/bloc/cart/cart_bloc.dart';
import 'package:httpreq/screen/Productdetail.dart';
import 'package:httpreq/screen/cart_page.dart';
import 'package:httpreq/scrollable_list_tab_scroller.dart';



import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';

import 'common/widgets/card.dart';

class MyHomePagee extends StatefulWidget {
  var value;
  var index;

  MyHomePagee({
    Key? key,
    @required this.value,
    @required this.index,
  }) : super(key: key);

  @override
  _MyHomePageeState createState() => _MyHomePageeState();
}

class _MyHomePageeState extends State<MyHomePagee> {
  final ItemScrollController itemScrollController = ItemScrollController();
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      var inde = widget.index;
      itemScrollController.jumpTo(index: inde);
    });
  }

  @override
  Widget build(BuildContext context) {
    var item = widget.value;
    final ScrollController _controller = ScrollController();
    

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            const rowofitems(),
            Expanded(
              child: ScrollableListTabScroller(
                tabBuilder: (BuildContext context, int index, bool active) =>
                    Padding(
                  padding: const EdgeInsets.only(right: 10, bottom: 10),
                  child: Container(
                    
                    decoration: BoxDecoration(
                        color: !active ? null : Colors.black,
                        border: Border.all(
                          color: Colors.black,
                        ),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(20))),
                    child: Center(
                      child: Text(
                        widget.value[index].displayName,
                         key: Key( 'horizontal'+ widget.value[index].displayName ),
                        
                        textAlign: TextAlign.center,
                        softWrap: true,
                        style: !active
                            ? const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                                color: Colors.black)
                            : const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                                color: Colors.white),
                      ),
                      
                    ),
                    
                  ),
                ),
                itemScrollController: itemScrollController,
                itemCount: widget.value.length,
                itemBuilder: (BuildContext context, int index) => Padding(
                  padding: const EdgeInsets.only(top: 5),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          widget.value[index].displayName,
                          key:  Key('Vertical'+widget.value[index].displayName),
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 20),
                        ),
                      ),
                      ListView.builder(
                          controller: _controller,
                          shrinkWrap: true,
                          scrollDirection: Axis.vertical,
                          padding: const EdgeInsets.all(8),
                          itemCount: widget.value[index].items.length,
                          itemBuilder: (BuildContext context, int i) {
                            return Column(
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => Productdetail(
                                                value: widget
                                                    .value[index].items[i])));
                                  },
                                  child: card(
                                    displayName: widget
                                        .value[index].items[i].displayName,
                                    // ignore: prefer_interpolation_to_compose_strings
                                    image:
                                        "https://mnumenuprddataae.azureedge.net/" +
                                            widget.value[index].items[i].images,
                                    description: widget
                                        .value[index].items[i].description,
                                    price: widget.value[index].items[i].price,
                                  ),
                                ),
                              ],
                            );
                          }),
                    ],
                  ),
                ),
              ),
            ),
            Card(
              child:
                  BlocBuilder<CartBloc, CartState>(builder: (context, state) {
             

                if (state is CartLoaded) {
                  // final isInCart = state.cart.items.contains(item);
                  // return Container(child:Text(state.cart.items.toString()),);
                  final a = state.cart.items.length;
                  if (a > 0) {
                    return Visibility(
                        visible: true, child: PopUpCart(value: widget.value));
                  }
                }
                return Visibility(
                    visible: false, child: PopUpCart(value: widget.value));
              }),
            ),
          ],
        ),
      ),
    );
  }
}

class rowofitems extends StatefulWidget {
  const rowofitems({Key? key}) : super(key: key);

  @override
  State<rowofitems> createState() => _rowofitemsState();
}

class _rowofitemsState extends State<rowofitems> {
  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: const BackButtonIcon(),
        ),
        IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: const ImageIcon(
            AssetImage("assets/drink.png"),
          ),
        ),
        Container(
          padding: const EdgeInsets.all(10),
          child: Text(
            "Drink",
            textAlign: TextAlign.center,
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ),

        IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: const ImageIcon(
            AssetImage("assets/fork.png"),
          ),
        ),
        Container(
          padding: EdgeInsets.all(10),
          child: Text(
            'Food',
            textAlign: TextAlign.center,
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ),

        const SizedBox(width: 60),
        IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: const Icon(Icons.search),
        ),

        //getvertical(),
      ],
    );
  }
}

class PopUpCart extends StatefulWidget {
  var value;
  PopUpCart({super.key, @required value});

  @override
  State<PopUpCart> createState() => _PopUpCartState();
}

class _PopUpCartState extends State<PopUpCart> {
  @override
  Widget build(BuildContext context) {
    var item = widget.value;
    var list = [1];

    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
      ),
      onPressed: () {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => const CartPage()));
      },
      child: Container(
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.all(10),
        margin: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(0, 0),
            ),
          ],
        ),
        child: SizedBox(
          height: 30.0,
          width: 30.0,
          child: GestureDetector(
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => const CartPage()));
              },
              child: Row(
                children: [
                  const SizedBox(width: 100),
                  Text(
                    "View cart",
                    textAlign: TextAlign.center,
                    style: GoogleFonts.getFont(
                      'Rubik',
                      fontSize: 14,
                      color: Colors.white,
                      decoration: TextDecoration.none,
                    ),
                  ),
                  Stack(
                    children: <Widget>[
                      const IconButton(
                        icon: Icon(
                          Icons.shopping_cart,
                          color: Colors.white,
                        ),
                        onPressed: null,
                      ),
                      list.isEmpty
                          ? Container()
                          : Positioned(
                              child: Stack(
                              children: <Widget>[
                                Icon(Icons.brightness_1,
                                    size: 20.0, color: Colors.green[800]),
                                Positioned(
                                    top: 3.0,
                                    right: 6.0,
                                    child: Center(
                                      child: BlocBuilder<CartBloc, CartState>(
                                        builder: (context, state) {
                                          //   print(state);

                                          if (state is CartLoaded) {
                                            final isInCart =
                                                state.cart.items.contains(item);

                                            final a = state.cart.items.length;
                                            return Text(
                                              a.toString(),
                                            );
                                          }
                                          return const Text(
                                              'Something went wrong!');
                                        },
                                      ),
                                    )),
                              ],
                            )),
                    ],
                  ),
                ],
              )),
        ),
      ),
    );
  }
}
