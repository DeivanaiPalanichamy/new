import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:httpreq/bloc/cart/cart_bloc.dart';
import 'package:httpreq/screen/Productdetail.dart';

import '../shopping_repository.dart';
import 'Home.dart';

class CartPage extends StatefulWidget {
  // ignore: prefer_typing_uninitialized_variables
  // final value;

  const CartPage({
    super.key,
  });

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            InkWell(
              onTap: () {
                Navigator.of(context).pop();
              },
              child: const SizedBox(
                width: 35,
                height: 35,
                child: Icon(Icons.close),
              ),
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Text(
                "Cart",
                key: Key('Cart'),
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 28,
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.none,
                ),
              ),
            ),
            featured(),
            SizedBox(height: 10),
            Container(
              height: 40.0,
              width: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.all(10),
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.grey,
                    offset: Offset(0, 0),
                  ),
                ],
              ),
              child: Text(
                "DRINKS",
                textAlign: TextAlign.center,
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 14,
                  color: Colors.black,
                  decoration: TextDecoration.none,
                ),
              ),
            ),
            Expanded(
              child: Row(
                children: const [
                  Padding(padding: EdgeInsets.all(5)),
                  cartprice(),
                  SizedBox(height: 15),
                ],
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.all(10),
              decoration: const BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.white,
                    offset: Offset(0, 0),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Icon(Icons.shopping_cart),
                  Text(
                    "Add a promo code",
                    textAlign: TextAlign.center,
                    style: GoogleFonts.getFont(
                      'Rubik',
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      decoration: TextDecoration.none,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            CartTotal(),
            Align(
              alignment: Alignment.center,
              child: Text(
                "Add more items",
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  decoration: TextDecoration.none,
                ),
              ),
            ),
            Container(
              height: MediaQuery.of(context).size.height / 15,
              width: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.all(15),
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(0, 0),
                  ),
                ],
              ),
              child: Text(
                "Go to checkout",
                textAlign: TextAlign.center,
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 17,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.none,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class cartprice extends StatelessWidget {
  const cartprice({super.key});

  @override
  Widget build(BuildContext context) {
    double sum = 0.0;

    return Expanded(
      child: BlocBuilder<CartBloc, CartState>(builder: (context, state) {
        if (state is CartLoaded) {
          return ListView.builder(
              itemCount: state.cart.variant.length,
              itemBuilder: (context, index) {
                final item = state.cart.items[index];

                final List<String> pric = state.cart.variant;

                for (int i = 0; i < pric.length; i++) {
                  var price = double.parse(pric[i]);
                  sum = sum + price;
                }
               
                final variant = state.cart.variant[index].toString();

                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      child: Text(
                        (index + 1).toString(),
                        textAlign: TextAlign.center,
                        style: GoogleFonts.getFont(
                          'Rubik',
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.65,
                      child: Text(
                        state.cart.items[index].displayName.toString(),
                        textAlign: TextAlign.start,
                        style: GoogleFonts.getFont(
                          'Rubik',
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        context
                            .read<CartBloc>()
                            .add(CartItemRemoved(item, variant));
                      },
                      child: const SizedBox(
                        width: 35,
                        height: 10,
                        child: Icon(Icons.remove),
                      ),
                    ),
                    Row(
                      children: [
                        Text(
                          "\$",
                          textAlign: TextAlign.end,
                          style: GoogleFonts.getFont(
                            'Rubik',
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                            decoration: TextDecoration.none,
                          ),
                        ),
                        Text(
                          state.cart.variant[index].toString() == null
                              ? ""
                              : state.cart.variant[index].toString(),
                          textAlign: TextAlign.end,
                          style: GoogleFonts.getFont(
                            'Rubik',
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                            decoration: TextDecoration.none,
                          ),
                        ),
                      ],
                    ),
                  ],
                );
              });
        }
        return const Text('Something went wrong!');
      }),
    );
  }
}

class CartTotal extends StatelessWidget {
  const CartTotal({super.key});

  @override
  Widget build(BuildContext context) {
    double sum = 0.0;

    return BlocBuilder<CartBloc, CartState>(builder: (context, state) {
      if (state is CartLoaded) {
        final List<String> pric = state.cart.variant;
        for (int i = 0; i < pric.length; i++) {
          var price = double.parse(pric[i]);
          sum = sum + price;
        }

        return SizedBox(
          height: 15,
          child: Row(
            children: [
              SizedBox(width: 10),
              Text(
                "Item total",
                textAlign: TextAlign.end,
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  decoration: TextDecoration.none,
                ),
              ),
              SizedBox(width: 230),
              Container(
                height: MediaQuery.of(context).size.height / 15,
                child: Row(
                  children: [
                    Text(
                      "\$",
                      textAlign: TextAlign.end,
                      style: GoogleFonts.getFont(
                        'Rubik',
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    Text(
                      sum.toString(),
                      textAlign: TextAlign.end,
                      style: GoogleFonts.getFont(
                        'Rubik',
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      }
      return Text("something wnt wrong");
    });
  }
}
