import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AccountDetail extends StatefulWidget {
  const AccountDetail({super.key});

  @override
  State<AccountDetail> createState() => _AccountDetailState();
}

class _AccountDetailState extends State<AccountDetail> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(child:Material(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
       
        children: [
           const Padding(padding: EdgeInsets.all(10)),
          Row(
            children: [
              InkWell(
              onTap: () {
                Navigator.of(context).pop();
              },
               child:const SizedBox(
                width: 35,
                height: 35,
                child: Icon(Icons.close),
              ),),
              SizedBox(
                width: 180,
              ),
              Text(
                "Existing account?",
                textAlign: TextAlign.left,
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 13,
                  color: Colors.blueGrey,
                ),
              ),
              Text(
                "Sign In",
                textAlign: TextAlign.left,
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ],
          ),
          Text(
            "Confirm your details",
            textAlign: TextAlign.left,
            style: GoogleFonts.getFont(
              'Rubik',
              fontSize: 23,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(height: 40),
          Row(
            children: [
              Text(
                "First name",
                textAlign: TextAlign.left,
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(width: 5),
              Text(
                "(Required)",
                textAlign: TextAlign.left,
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 13,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
          TextFormField(
            decoration: const InputDecoration(
              border: UnderlineInputBorder(),
              labelText: 'First name',
            ),
          ),
          SizedBox(height: 40),
          Row(
            children: [
              Text(
                "Last name",
                textAlign: TextAlign.left,
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(width: 5),
              Text(
                "(Required)",
                textAlign: TextAlign.left,
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 13,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
          TextFormField(
            decoration: const InputDecoration(
              border: UnderlineInputBorder(),
              labelText: 'Last name',
            ),
          ),
          SizedBox(height: 40),
          Row(
            children: [
              Text(
                "Phone number",
                textAlign: TextAlign.left,
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(width: 5),
              Text(
                "(Required)",
                textAlign: TextAlign.left,
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 13,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
         /* Card(
            child: IntlPhoneField(
              decoration: const InputDecoration(
                labelText: '0499 999 999',
                border: OutlineInputBorder(
                  borderSide: BorderSide(),
                ),
              ),
              initialCountryCode: 'IN',
              onChanged: (phone) {
                print(phone.countryCode);
              },
            ),
          ),*/
          Text(
            "For SMS notifications about your order.",
            textAlign: TextAlign.left,
            style: GoogleFonts.getFont(
              'Rubik',
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
          ),
          SizedBox(height: 40),
          Text(
            "Email",
            textAlign: TextAlign.left,
            style: GoogleFonts.getFont(
              'Rubik',
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 5),
          TextFormField(
            decoration: const InputDecoration(
              border: UnderlineInputBorder(),
              labelText: 'Email',
            ),
          ),
          Text(
            "Optional:Get receipts with every order.",
            textAlign: TextAlign.left,
            style: GoogleFonts.getFont(
              'Rubik',
              fontSize: 15,
              color: Colors.grey,
            ),
          ),
          SizedBox(height: 90),
          Card(
            child: Container(
              height: MediaQuery.of(context).size.height / 15,
              width: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.all(15),
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    offset: Offset(0, 0),
                  ),
                ],
              ),
              child: Text(
                "Save details",
                textAlign: TextAlign.center,
                style: GoogleFonts.getFont(
                  'Rubik',
                  fontSize: 16,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.none,
                ),
              ),
            ),
          ),
        ],
      ),),
    );
  }
}
