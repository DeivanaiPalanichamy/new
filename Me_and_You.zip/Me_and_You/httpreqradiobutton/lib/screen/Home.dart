import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:httpreq/bloc/posts/post_bloc.dart';
import 'package:httpreq/screen/Accountdetail.dart';
import 'package:flutter_driver/driver_extension.dart';
import 'productHomepage.dart';

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          body: SafeArea(
            child: Center(
              child: BlocBuilder<PostBloc, PostState>(
                  builder: (context, snapshot) {
                switch (snapshot.status) {
                  case PostStatus.failure:
                    return const Center(child: Text('failed to fetch posts'));
                  case PostStatus.success:
                    if (snapshot.categories.isEmpty) {
                      return const Center(child: Text('no posts'));
                    }
                    return ListView(
                      padding: const EdgeInsets.all(8),
                      children: [
                        const heroimage(),
                        const featured(),
                        grid(value: snapshot.categories),
                        RichText(
                          text: const TextSpan(
                            text:
                                'Prices are displayed in local currency. Venue and/or payment',
                            style: TextStyle(color: Colors.grey, fontSize: 14),
                            children: <TextSpan>[
                              TextSpan(
                                text:
                                    'surcharges may apply, please review all charges before submitting',
                              ),
                              TextSpan(
                                text: 'your order.',
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  case PostStatus.initial:
                    return const Center(
                        child:
                            CircularProgressIndicator()); // Container(child:Text(snapshot.data!.categories.toString()),),
                }
              }),
            ),
          ),
          bottomNavigationBar: BottomNavigationBar(
            
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: ImageIcon(
                  AssetImage("assets/book.png.png"),
                ),
                label: 'MENU',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.group),
                label: 'GROUP TABS',
              ),
              BottomNavigationBarItem(
                icon: ImageIcon(
                  AssetImage("assets/person.png"),
                ),
                label: 'PROFILE',
              ),
            ],
          ),
        ),
      
    );
  }
}

class featured extends StatefulWidget {
  const featured({Key? key}) : super(key: key);

  @override
  State<featured> createState() => _featuredState();
}

class _featuredState extends State<featured> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height / 6,
      width: MediaQuery.of(context).size.width,
      //height: 125.0,
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        boxShadow: const [
          BoxShadow(
            color: Colors.black,
            offset: Offset(6.0, 6.0),
          ),
        ],
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => AccountDetail()));
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Tab(
                  icon: Container(
                    padding: const EdgeInsets.all(8),
                    child: const Image(
                      image: AssetImage(
                        'assets/diamond.png',
                      ),
                      //color: Colors.black,
                      fit: BoxFit.cover,
                      height: 50,
                      width: 35,
                    ),
                  ),
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Get member offers with every order with',
                      textAlign: TextAlign.left,
                      style: GoogleFonts.getFont(
                        'Rubik',
                        fontSize: 13,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'Your test - Penrith Panther - Squires Bar',
                      textAlign: TextAlign.start,
                      style: GoogleFonts.getFont(
                        'Rubik',
                        fontSize: 13,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'membership.',
                      textAlign: TextAlign.start,
                      style: GoogleFonts.inter(
                        fontSize: 13,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Link Account',
                      textAlign: TextAlign.start,
                      style: GoogleFonts.getFont(
                        'Rubik',
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class grid extends StatefulWidget {
  // ignore: prefer_typing_uninitialized_variables
  var value;
  grid({Key? key, @required this.value}) : super(key: key);

  @override
  State<grid> createState() => _gridState();
}

// ignore: camel_case_types
class _gridState extends State<grid> {
  @override
  Widget build(BuildContext context) {
    final ScrollController controller = ScrollController();
    return GridView.builder(
        controller: controller,
        shrinkWrap: true,
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 280,
          crossAxisSpacing: 0,
          mainAxisSpacing: 10,
        ),
        //  padding: const EdgeInsets.all(2),
        itemCount: widget.value.length,
        itemBuilder: (BuildContext context, int index) {
         
          return GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder:
                                  (context) => /* listviewItems(
                                    value: (widget.value),
                                  )*/
                                      MyHomePagee(
                                          value: widget.value, index: index)));
                    },

                    ///Display of categories of images.
                    child:Container(
            margin: const EdgeInsets.all(8),
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child:  Container(
                      height: MediaQuery.of(context).size.height / 6,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: NetworkImage(
                              // ignore: prefer_interpolation_to_compose_strings
                              "https://mnumenuprddataae.azureedge.net/" +
                                  widget.value[index].images),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                
                const SizedBox(height: 10),
                Text(
                  widget.value[index].displayName.toString(),
                  key: Key(widget.value[index].displayName.toString()),
                
                  textAlign: TextAlign.start,
                  style: GoogleFonts.getFont(
                    'Rubik',
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    //fontWeight: FontWeight.bold,
                  ),
                ),
                 
              ],
            ),),
          );
        });
  }
}

class heroimage extends StatefulWidget {
  const heroimage({
    Key? key,
  }) : super(key: key);

  @override
  State<heroimage> createState() => _heroimageState();
}

class _heroimageState extends State<heroimage> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          height: 250,
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: NetworkImage(
                "https://mnumenuprddataae.azureedge.net/6086/608646ff5d314e1bc047e46e/hero/171adafba6254d9fa35c748926091b66-full.png",
              ),
              fit: BoxFit.fill,
            ),
          ),
        ),
        Positioned(
          child: Container(
              height: 250,
              width: 500,
              padding: const EdgeInsets.all(80),
              child: SvgPicture.network(
                "https://mnumenuprddataae.azureedge.net/6086/608646ff5d314e1bc047e46e/logo/666721a9b1b644f6a7f477b408e6628e-orig.svg",
                semanticsLabel: 'SVG From Network',
                color: Colors.white,
                placeholderBuilder: (BuildContext context) => Container(
                    padding: const EdgeInsets.all(25.0),
                    child: const CircularProgressIndicator()),
              )),
        ),
        Align(
          alignment: Alignment.topRight,
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: ClipOval(
              child: Material(
                color: Colors.grey,
                child: InkWell(
                  onTap: () {},
                  child: const SizedBox(
                    width: 35,
                    height: 35,
                    child: Icon(Icons.search),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
