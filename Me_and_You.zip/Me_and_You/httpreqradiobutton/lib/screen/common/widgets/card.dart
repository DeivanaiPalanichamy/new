/* 
 Version # : 6
Modified Date & By :  -17/10/2022- & -Deivanai-
Changes Summary: I had seperated the card from Second route to form tree widget format.
 */

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ignore: must_be_immutable, camel_case_types
class card extends StatefulWidget {
  // ignore: prefer_typing_uninitialized_variables
  var displayName;
  // ignore: prefer_typing_uninitialized_variables
  var image;
  // ignore: prefer_typing_uninitialized_variables
  var description;
  // ignore: prefer_typing_uninitialized_variables
  var price;

  card({
    Key? key,@required this.displayName,@required this.image,@required this.description,@required this.price,}) : super(key: key);

  @override
  State<card> createState() => _cardState();
}

// ignore: camel_case_types
class _cardState extends State<card> {
  @override
  Widget build(BuildContext context) {
    
    return Card(
    
      /// For displaying image ,displayName,description and price.
      child: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height/7,
            width:MediaQuery.of(context).size.width,
            padding:const EdgeInsets.all(2),
            margin: const EdgeInsets.all(8),
            child: Row(
              children: [
               ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Container(
                    height:  MediaQuery.of(context).size.height/7,
                    width:  MediaQuery.of(context).size.width/5,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: NetworkImage(
                          ///To display the image of items fetched from secondRoute.
                          widget.image,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                 Expanded(child:Column(
                
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                
                    Text(
                      ///To display the displayname of items fetched from secondRoute.
                      widget.displayName,
                       key: Key( widget.displayName ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.start,
                      style: GoogleFonts.getFont(
                        'Rubik',
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    Column(
                      children: [
                       // Padding(padding:EdgeInsets.all(2)),
                        SizedBox(
                          
                          width:  200,
                          child: Text(
                            ///To display the description of items fetched from secondRoute.
                           widget.description ?? "empty",
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.start,
                            style: GoogleFonts.getFont(
                              'Rubik',
                              fontSize: 13,
                              fontWeight: FontWeight.w400,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),
                    Text(
                      ///To display the price of items fetched from secondRoute.
                      widget.price ?? "empty",
                      textAlign: TextAlign.start,
                      style: GoogleFonts.getFont(
                        'Rubik',
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),),
              
            
         ],), ),
        ],
      ),
    );
  }
}
